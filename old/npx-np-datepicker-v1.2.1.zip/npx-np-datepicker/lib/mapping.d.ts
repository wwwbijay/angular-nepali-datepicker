import { MonthMapping, DaysMapping, WordsMapping } from './types';
export declare const numberMapping: string[];
export declare const wordsMapping: WordsMapping;
export declare const daysMapping: DaysMapping;
export declare const monthsMapping: MonthMapping;

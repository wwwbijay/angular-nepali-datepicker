import * as i0 from "@angular/core";
import * as i1 from "./to-np.pipe";
import * as i2 from "./np-datepicker.component";
import * as i3 from "@angular/platform-browser";
import * as i4 from "@angular/forms";
export declare class NepaliDatepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NepaliDatepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NepaliDatepickerModule, [typeof i1.ToNpPipe, typeof i2.NpDatePickerComponent], [typeof i3.BrowserModule, typeof i4.FormsModule], [typeof i2.NpDatePickerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NepaliDatepickerModule>;
}
